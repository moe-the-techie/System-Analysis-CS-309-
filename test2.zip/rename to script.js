document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM Loaded");

    const table = document.getElementById("ContentPlaceHolder2_GridView1");
    const rows = table.getElementsByTagName("tr");
    
    const data = [];
    const headers = [];
    // get headers from first table row

    for (let i = 1; i < rows.length; i++) { // start from 1 to skip header row
        // fill data with rows contents
    }

    const filteredData = []; // filter data so that only passing rows are filtered
    const groupedData = filteredData.reduce((acc, row) => {
        // create array for each level
    }, {});

    Object.keys(groupedData).forEach(group => {
        const groupDiv = document.createElement("div");
        // fill groupDiv with passed subjects

        table.insertAdjacentElement('beforeBegin', groupDiv);
    });

    // show unfinished subjects in other divs
    
    console.log("DOM Finished");
});